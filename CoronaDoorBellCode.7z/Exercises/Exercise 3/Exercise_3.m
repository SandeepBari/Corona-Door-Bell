clc;
close all;
clear all;

try
    %%
    % Input Box
    answer = inputdlg({'Enter Number 1:','Enter Number 2:','Enter Number 3:'},...
        'Input',[1 35],{'0','0','0'});
    
    inp1= answer{1,1};
    inp2= answer{2,1};
    inp3= answer{3,1};
    
    % Specify the name of the model to create
    modelName = 'Exercise_3_Model';
    
    % Check if the file already exists and delete it if it does
    if exist(modelName,'file') == 4
        if bdIsLoaded(modelName)
            % If it is then close it (without saving!)
            close_system(modelName,0)
        end
        delete([modelName,'.slx']);
    end
    
    % Create the system
    new_system(modelName);
    
    %%
    % Add Constants
    
    C1= add_block('built-in/constant', [gcs,'/C1'],...
        'Position',[100 60 130 100] );
    
    C2= add_block('built-in/constant', [gcs,'/C2'],...
        'Position', [100 150 130 190]);
    
    C3= add_block('built-in/constant', [gcs,'/C3'],...
        'Position', [100 240 130 270]);
    
    %%
    % Add Sum blocks
    sumAdDivide= add_block('built-in/Sum', [gcs,'/sum1'],...
        'Position',[240 60 270 90]);
    
    sumAdd2= add_block('built-in/Sum', [gcs,'/sum2'],...
        'Position',[300 60 330 90]);
    
    display1= add_block('built-in/display', [gcs,'/display1'],...
        'Position',[350 65 380 100]);
    
    % Connect the C1 to Sum1
    add_line(gcs,'C1/1','sum1/1');
    
    % Connect the C2 to Sum1
    add_line(gcs,'C2/1','sum1/2');
    
    % Connect the Sum1 to Sum2
    add_line(gcs,'sum1/1','sum2/1');
    
    % Connect the C3 to Sum2
    add_line(gcs,'C3/1','sum2/2');
    
    % Connect the Sum2 to display1
    add_line(gcs,'sum2/1','display1/1');
    
    %%
    % Add Product blocks
    proDivide= add_block('built-in/Product', [gcs,'/product1'],...
        'Position',[240 150 270 180]);
    
    prod2= add_block('built-in/Product', [gcs,'/product2'],...
        'Position',[300 150 330 180]);
    
    % Add a Display block
    display2= add_block('built-in/display', [gcs,'/display2'],...
        'Position',[350 150 390 190]);
    
    % Connect the C1 to product1
    add_line(gcs,'C1/1','product1/1');
    
    % Connect the C2 to product1
    add_line(gcs,'C2/1','product1/2');
    
    % Connect the product1 to product2
    add_line(gcs,'product1/1','product2/1');
    
    % Connect the C3 to product2
    add_line(gcs,'C3/1','product2/2');
    
    % Connect the product2 to display2
    add_line(gcs,'product2/1','display2/1');
    
    %%
    % Add Divide blocks
    Divide= add_block('simulink/Math Operations/Divide', [gcs,'/Divide'],...
        'Position',[280 220 310 250] );
    
    % Add a Display block
    display3= add_block('built-in/display', [gcs,'/display3'],...
        'Position',[350 220 390 255] );
    
    % Connect the C1 to Divide
    add_line(gcs,'C1/1','Divide/1');
    
    % Connect the C2 to Divide
    add_line(gcs,'C2/1','Divide/2');
    
    % Connect the Divide to display3
    add_line(gcs,'Divide/1','display3/1');
    
    %%
    % Add Exponent blocks
    Exponent= add_block('simulink/Math Operations/Math Function', [gcs,'/Exponent'],...
        'Position',[280 280 310 310] );
    
    % Add a Display block
    display4= add_block('built-in/display', [gcs,'/display4'],...
        'Position',[340 280 380 310] );
    
    set_param('Exercise_3_Model/Exponent','Function','pow');
    
    % Connect the C1 to Exponent
    add_line(gcs,'C1/1','Exponent/1');
    
    % Connect the C2 to Exponent
    add_line(gcs,'C2/1','Exponent/2');
    
    % Connect the Exponent to display4
    add_line(gcs,'Exponent/1','display4/1');
    
    %%
    % Add Subtract blocks
    Subt= add_block('simulink/Math Operations/Subtract', [gcs,'/subt'],...
        'Position',[270 340 300 370] );
    
    % Add a Display block
    display4= add_block('built-in/display', [gcs,'/display5'],...
        'Position',[340 340 380 370] );
    
    % Connect the C1 to Subtract
    add_line(gcs,'C1/1','subt/1');
    
    % Connect the C2 to Subtract
    add_line(gcs,'C2/1','subt/2');
    
    % Connect the Exponent to display5
    add_line(gcs,'subt/1','display5/1');
    
    %%
    %Setting Parameters
    set_param('Exercise_3_Model/C1','value',inp1);
    set_param('Exercise_3_Model/C2','value',inp2);
    set_param('Exercise_3_Model/C3','value',inp3);
    
    % Save the model
    save_system(modelName);
    
    %Simulate the Simulink Model
    sim(modelName);
    
catch
    msgbox('Inavlid Input','Error');
end
