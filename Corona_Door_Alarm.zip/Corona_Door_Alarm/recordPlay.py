import serial
import sounddevice
import time

from scipy.io.wavfile import write
from playsound import playsound
 
arduinoSerialData = serial.Serial('COM9',9600) 
 
while (1==1):
	if (arduinoSerialData.inWaiting()>0):
		myData = arduinoSerialData.readline()
		fs= 44100
		second= 5
		print('Now You can Call Mr.Chetan Mali and Her Family ')
		record_voice= sounddevice.rec(int(fs*second),samplerate= fs,channels= 2)
		sounddevice.wait()
		write("someoneAtDoor.wav",fs,record_voice)
		print('Someone At Door')
		playsound('someoneAtDoor.wav')
		break